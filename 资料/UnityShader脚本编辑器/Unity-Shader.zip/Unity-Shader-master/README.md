# Unity-Shader
Unity-Shader (Sublime Extern)

在https://github.com/petereichinger/Unity3D-Shader 基础上添加的sublime shader 高亮和智能提示插件

1.语法高亮 (基于https://github.com/petereichinger/Unity3D-Shader的语法高亮功能)

2.智能提示(对于常用的unity api 和 shader api 提供基本的提示功能)

3.提示跳转(对于封装在cginclude 文件夹中的unity 内置文件,提供了部分跳转功能)

Tips:

下载完之后,放到sublime的packages文件夹 并且需要重命名为"Unity-Shader"(因为当下载zip的时候是会有master后缀名的)

2015.9.6 

update unity5 